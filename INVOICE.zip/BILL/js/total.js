let amount1 = document.getElementById('amount1'),
    amount2 = document.getElementById('amount2'),
    amount3 = document.getElementById('amount3'),
    amount4 = document.getElementById('amount4'),
    amount5 = document.getElementById('amount5'),
    amount6 = document.getElementById('amount6'),
    amount7 = document.getElementById('amount7'),
    amount8 = document.getElementById('amount8'),
    total = document.getElementById('total'),
    subtotal = document.getElementById('subtotal'),
    tax = document.getElementById('tax'),
    discount = document.getElementById('discount');
    

setInterval(totalcalc, 100);

let totalbill,
    finaltotal;

function totalcalc(){
    totalbill = Number(amount1.value) + Number(amount2.value) + Number(amount3.value) + Number(amount4.value) + Number(amount5.value) + Number(amount6.value) + Number(amount7.value) + Number(amount8.value);
    subtotal.value = totalbill;
    finaltotal = totalbill + (totalbill * 0.01 * (tax.value - discount.value));
    total.textContent = JSON.stringify(Math.round(finaltotal));
}

